BRUHH NOVEL — PROJECT APK ANDROID

Isi:
- app/src/main/assets/index.html : versi HTML BRUHH NOVEL yang dibungkus ke aplikasi.
- WebView Android: JavaScript + localStorage aktif, internet diizinkan untuk YouTube/konten online.
- GitHub Actions: membangun APK debug secara otomatis.

CARA PALING MUDAH DARI HP:
1. Ekstrak ZIP ini.
2. Upload semua isi folder ke repository GitHub baru bernama BruhhNovel (branch main).
3. Buka tab Actions di repository.
4. Jalankan workflow "Build BRUHH NOVEL APK" jika belum berjalan otomatis.
5. Buka hasil workflow yang selesai, bagian Artifacts.
6. Unduh BRUHH-NOVEL-APK.zip, ekstrak, lalu install app-debug.apk di Android.

CATATAN:
- Ini adalah proyek sumber Android, bukan APK jadi.
- APK debug belum ditandatangani untuk publikasi Play Store.
- Cerita dan gambar yang sudah ada di HTML disimpan sebagai aset lokal.
- YouTube dan konten online membutuhkan internet. YouTube dapat menolak embed pada video tertentu.
- Android WebView memerlukan interaksi pengguna untuk memulai playback pada beberapa perangkat.
